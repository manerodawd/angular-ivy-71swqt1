import { Component, OnInit } from '@angular/core';
import { FrutasModule } from '../frutas.module';
import { Frutas } from '../frutas';
import { FrutasService } from '../frutas.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent implements OnInit {
  FrutasForm: Frutas = {
    id: 0,
    name: '',
    price: 0,
    quantity: 0
  }
  constructor(private frutaService: FrutasService, private route: Router) { }

  ngOnInit(): void {
  }

  createFrutas(){
    this.frutaService.create(this.FrutasForm)
    .subcribe({
      next:(data) => {
        this.router
      }
    })
  }

}
