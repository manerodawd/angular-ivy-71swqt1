import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FrutasRoutingModule } from './frutas-routing.module';
import { HomeComponent } from './home/home.component';
import { CreateComponent } from './create/create.component';


@NgModule({
  declarations: [
    HomeComponent,
    CreateComponent
  ],
  imports: [
    CommonModule,
    FrutasRoutingModule
  ]
})
export class FrutasModule { }
