import { Component, OnInit } from '@angular/core';
import { FrutasModule } from '../frutas.module';
import { Frutas } from '../frutas';
import { FrutasService } from '../frutas.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  allFrutas: Frutas[] = [];

  constructor(private frutasService: FrutasService) { }

  ngOnInit(): void {
  }
  getFrutas(){
    this.frutasService.get()
      .subscribe((data: any) => {
        this.allFrutas = data;
      })
  }
}
